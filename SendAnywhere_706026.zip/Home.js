const Home = () => {
    return(
        <ha className="Home">Home Page </ha>
    );
}
export default Home;